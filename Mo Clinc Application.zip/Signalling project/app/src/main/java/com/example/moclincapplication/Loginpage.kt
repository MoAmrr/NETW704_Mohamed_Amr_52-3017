package com.example.moclincapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Loginpage : AppCompatActivity() {

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loginpage)

        val location = findViewById<ImageButton>(R.id.imageButton5)
        val profilepage = findViewById<ImageButton>(R.id.prooooo)

        location.setOnClickListener {
            val intentLocation = Intent(this, MapsActivity::class.java)
            startActivity(intentLocation)
        }

        profilepage.setOnClickListener {
            val intentProfile = Intent(this, profile::class.java) // Correct this line
            startActivity(intentProfile)
        }
    }
}

