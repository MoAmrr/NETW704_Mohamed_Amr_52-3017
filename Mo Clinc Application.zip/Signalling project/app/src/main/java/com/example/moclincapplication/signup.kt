package com.example.moclincapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth

class signup : AppCompatActivity() {
    private lateinit var auth1: FirebaseAuth
    private lateinit var signupEmail1: EditText
    private lateinit var signupPassword1: EditText
    private lateinit var loginButton1: Button
    private lateinit var back1: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        auth1 = FirebaseAuth.getInstance()
        signupEmail1 = findViewById(R.id.emailbtn1)
        signupPassword1 = findViewById(R.id.passbtn1)
        loginButton1 = findViewById(R.id.login_btn1)
        back1 = findViewById(R.id.backbutton2)


        back1.setOnClickListener {
            startActivity(Intent(this@signup, MainActivity::class.java))
        }

        loginButton1.setOnClickListener {
            val user = signupEmail1.text.toString().trim()
            val pass = signupPassword1.text.toString().trim()

            if (user.isEmpty()) {
                signupEmail1.error = "Email cannot be Empty"
            }
            if (pass.isEmpty()) {
                signupPassword1.error = "Password cannot be Empty"
            }
            if (user.isNotEmpty() && pass.isNotEmpty()) {
                auth1.createUserWithEmailAndPassword(user, pass).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this@signup, "SignUp Successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@signup, Loginpage::class.java))
                    } else {
                        Toast.makeText(
                            this@signup,
                            "SignUp failed: ${task.exception?.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
        } }