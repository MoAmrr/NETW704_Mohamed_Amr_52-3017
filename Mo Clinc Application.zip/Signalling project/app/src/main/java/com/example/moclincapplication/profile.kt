package com.example.moclincapplication

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.example.moclincapplication.R

class profile : AppCompatActivity() {

    private lateinit var profilebtn2: EditText
    private lateinit var save: Button
    private lateinit var profilebtn: EditText

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        profilebtn2 = findViewById(R.id.editTextInput)
        save = findViewById(R.id.buttonSave)
        profilebtn = findViewById(R.id.editTextOutput)

        // Set up the button click listener
        save.setOnClickListener {
            saveData()
        }
    }

    private fun saveData() {
        val inputText = profilebtn2.text.toString()
        profilebtn.setText(inputText) // Set the text of the output EditText
    }
}
