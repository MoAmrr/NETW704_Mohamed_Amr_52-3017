package com.example.moclincapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.enableEdgeToEdge

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.moclincapplication.databinding.ActivityMapsBinding
import javax.annotation.Nonnull

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityMapsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_maps)
        //binding = ActivityMapsBinding.inflate(layoutInflater)
        //setContentView(binding.root)

        val mapFragment = supportFragmentManager.findFragmentById(R.id.map) as? SupportMapFragment
        mapFragment?.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        val guc = LatLng(29.9868, 31.4413)
        map.addMarker(MarkerOptions().position(guc).title("GUC Clinc"))
        map.moveCamera(CameraUpdateFactory.newLatLng(guc))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(guc,19f))

        val drugstore = LatLng(29.9861, 31.4411)
        map.addMarker(MarkerOptions().position(drugstore).title("drugstore"))
        map.moveCamera(CameraUpdateFactory.newLatLng(drugstore))
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(drugstore,19f))
    }
}