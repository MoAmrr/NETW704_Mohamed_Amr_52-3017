package com.example.moclincapplication

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.firebase.auth.FirebaseAuth


class signin : AppCompatActivity() {
    private lateinit var auth2: FirebaseAuth
    private lateinit var signupEmail2: EditText
    private lateinit var signupPassword2: EditText
    private lateinit var loginButton2: Button
    private lateinit var back2: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signin)

        auth2 = FirebaseAuth.getInstance()
        signupEmail2 = findViewById(R.id.email5btn2)
        signupPassword2 = findViewById(R.id.passbtn2)
        loginButton2 = findViewById(R.id.login_btn2)
        back2 = findViewById(R.id.backbutton1)


        back2.setOnClickListener {
            startActivity(Intent(this@signin, MainActivity::class.java))
        }

        loginButton2.setOnClickListener {
            val user = signupEmail2.text.toString().trim()
            val pass = signupPassword2.text.toString().trim()

            if (user.isEmpty()) {
                signupEmail2.error = "Email cannot be Empty"
            }
            if (pass.isEmpty()) {
                signupPassword2.error = "Password cannot be Empty"
            }
            if (user.isNotEmpty() && pass.isNotEmpty()) {
                auth2.signInWithEmailAndPassword(user, pass).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this@signin, "SignUp Successful", Toast.LENGTH_SHORT).show()
                        startActivity(Intent(this@signin, Loginpage::class.java))
                    } else {
                        Toast.makeText(
                            this@signin,
                            "SignUp failed: ${task.exception?.message}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    } }